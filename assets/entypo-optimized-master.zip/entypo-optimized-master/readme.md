# Entypo: Optimized and Sprited

> Entypo pictograms by Daniel Bruce — [www.entypo.com](http://www.entypo.com)

This is a quick little project for automating the optimization and spriting of the [Entypo](http://www.entypo.com) pictograms to make them ready-to-use in a web context.
